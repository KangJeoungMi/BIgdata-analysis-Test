"# Data-Analytics" 

[프로젝트 발표자료.pdf](https://github.com/JoonHyukSuh/Data-Analytics-/files/8423482/default.pdf)
[프로젝트 설명서(5조).pdf](https://github.com/JoonHyukSuh/Data-Analytics-/files/8423484/5.pdf)
